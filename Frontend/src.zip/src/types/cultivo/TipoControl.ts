export interface TipoControl {
    id? : number;
    nombre: string;
    descripcion: string;
  }