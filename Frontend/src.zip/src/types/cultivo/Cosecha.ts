export interface Cosecha {
    id?: number; 
    id_cultivo: number; 
    cantidad: number; 
    unidades_de_medida: string; 
    fecha: string;
  }