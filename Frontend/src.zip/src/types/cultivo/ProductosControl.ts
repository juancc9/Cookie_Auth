export interface ProductoControl {
    id?: number; 
    precio: number;
    nombre: string;
    compuestoActivo: string;
    fichaTecnica: string;
    Contenido: number;
    tipoContenido: string;
    unidades: number;
  }