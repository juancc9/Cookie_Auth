export interface Programacion {
    id?: number;
    ubicacion: string;
    hora_prog: string; 
    fecha_prog: string;
    estado: boolean;
}