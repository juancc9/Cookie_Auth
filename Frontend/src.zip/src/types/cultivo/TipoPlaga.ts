export interface TipoPlaga {
    id?: number;
    nombre: string;
    descripcion: string;
    img: File | null;
  }
  