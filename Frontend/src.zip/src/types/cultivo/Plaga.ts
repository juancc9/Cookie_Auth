export interface Plaga {
    id?: number;
    fk_tipo_plaga: number;
    nombre: string;
    descripcion: string;
    img: File | null;
  }
  