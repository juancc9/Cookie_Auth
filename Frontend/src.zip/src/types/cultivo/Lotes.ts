export interface Lote {
    id?: number;
    nombre: string;
    descripcion: string;
    activo: boolean;
    tam_x: number;
    tam_y: number;
    pos_x: number;
    pos_y: number;
  }
  