export interface BodegaHerramienta {
    id: number;
    bodega: number;
    herramienta: number; 
    cantidad: number;
}
