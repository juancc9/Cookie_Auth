export interface Herramienta {
    id: number;
    nombre: string;
    descripcion: string;
    cantidad: number;
    estado: string;
    activo: boolean;
    fecha_registro: string;
}