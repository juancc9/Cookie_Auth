export interface Bodega {
  id: number;
  nombre: string;
  direccion: string;
  telefono: string;
  activo: boolean;
  capacidad: number;  
  ubicacion: string;  
}
