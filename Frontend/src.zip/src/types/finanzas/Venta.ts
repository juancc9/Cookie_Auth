export interface Venta {
    id?: number;     
    producto: number;   
    cantidad: number;    
    total: number;     
    fecha: string;      
    precio: number;      
}
